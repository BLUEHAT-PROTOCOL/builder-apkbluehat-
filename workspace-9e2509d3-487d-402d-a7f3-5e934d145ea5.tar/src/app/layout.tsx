import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: 'Web App Builder - Buat Aplikasi Web dengan Mudah',
  description: 'Platform pembuatan aplikasi web dengan HTML, CSS, dan JavaScript. Buat website, portfolio, kalkulator, dan aplikasi lainnya dengan mudah.',
  keywords: ['web app builder', 'website builder', 'html editor', 'css editor', 'javascript editor', 'code editor', 'portfolio builder'],
  authors: [{ name: 'Web App Builder' }],
  creator: 'Web App Builder',
  publisher: 'Web App Builder',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    type: 'website',
    locale: 'id_ID',
    url: 'https://your-domain.pages.dev',
    title: 'Web App Builder - Buat Aplikasi Web dengan Mudah',
    description: 'Platform pembuatan aplikasi web dengan HTML, CSS, dan JavaScript. Buat website, portfolio, kalkulator, dan aplikasi lainnya dengan mudah.',
    siteName: 'Web App Builder',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Web App Builder - Buat Aplikasi Web dengan Mudah',
    description: 'Platform pembuatan aplikasi web dengan HTML, CSS, dan JavaScript. Buat website, portfolio, kalkulator, dan aplikasi lainnya dengan mudah.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <meta name="theme-color" content="#667eea" />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  );
}