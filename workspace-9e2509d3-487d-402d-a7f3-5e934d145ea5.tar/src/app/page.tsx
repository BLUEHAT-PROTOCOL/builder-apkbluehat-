'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import SimpleCodeEditor from '@/components/SimpleCodeEditor';
import { 
  FileText, 
  Download, 
  Play, 
  Plus, 
  Trash2, 
  Save,
  FolderOpen,
  Code,
  Eye,
  LayoutTemplate,
  Globe,
  Calculator,
  CheckSquare
} from 'lucide-react';

interface FileData {
  id: string;
  name: string;
  type: 'html' | 'css' | 'js' | 'json' | 'txt';
  content: string;
}

interface Template {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  files: FileData[];
}

const templates: Template[] = [
  {
    id: 'basic',
    name: 'Aplikasi Web Dasar',
    description: 'Template dasar dengan HTML, CSS, dan JavaScript',
    icon: <Globe className="h-6 w-6" />,
    files: [
      {
        id: '1',
        name: 'index.html',
        type: 'html',
        content: `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Saya</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Selamat Datang di Aplikasi Saya</h1>
        <p>Ini adalah aplikasi web yang dibuat dengan Web App Builder</p>
        <button onclick="sayHello()">Klik Saya</button>
    </div>
    <script src="script.js"></script>
</body>
</html>`
      },
      {
        id: '2',
        name: 'style.css',
        type: 'css',
        content: `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.container {
    background: white;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    text-align: center;
    max-width: 500px;
    width: 90%;
}

h1 {
    color: #333;
    margin-bottom: 1rem;
}

p {
    color: #666;
    margin-bottom: 1.5rem;
}

button {
    background: #667eea;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.3s;
}

button:hover {
    background: #5a6fd8;
}`
      },
      {
        id: '3',
        name: 'script.js',
        type: 'js',
        content: `function sayHello() {
    alert('Halo! Ini adalah aplikasi web yang Anda buat sendiri!');
}

// Tambahkan kode JavaScript Anda di sini
document.addEventListener('DOMContentLoaded', function() {
    console.log('Aplikasi siap digunakan!');
});`
      }
    ]
  },
  {
    id: 'portfolio',
    name: 'Portfolio Pribadi',
    description: 'Template portfolio modern untuk menampilkan profil Anda',
    icon: <LayoutTemplate className="h-6 w-6" />,
    files: [
      {
        id: '1',
        name: 'index.html',
        type: 'html',
        content: `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio Saya</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <h2 class="nav-logo">Portfolio</h2>
            <ul class="nav-menu">
                <li><a href="#home">Beranda</a></li>
                <li><a href="#about">Tentang</a></li>
                <li><a href="#projects">Proyek</a></li>
                <li><a href="#contact">Kontak</a></li>
            </ul>
        </div>
    </nav>

    <section id="home" class="hero">
        <div class="hero-content">
            <h1>Halo, Saya [Nama Anda]</h1>
            <p>Web Developer & Designer</p>
            <div class="hero-buttons">
                <a href="#projects" class="btn btn-primary">Lihat Proyek</a>
                <a href="#contact" class="btn btn-secondary">Hubungi Saya</a>
            </div>
        </div>
    </section>

    <section id="about" class="about">
        <div class="container">
            <h2>Tentang Saya</h2>
            <p>Saya adalah seorang web developer yang passionate dalam membuat aplikasi web yang indah dan fungsional.</p>
        </div>
    </section>

    <section id="projects" class="projects">
        <div class="container">
            <h2>Proyek Saya</h2>
            <div class="project-grid">
                <div class="project-card">
                    <h3>Proyek 1</h3>
                    <p>Deskripsi proyek pertama Anda</p>
                </div>
                <div class="project-card">
                    <h3>Proyek 2</h3>
                    <p>Deskripsi proyek kedua Anda</p>
                </div>
                <div class="project-card">
                    <h3>Proyek 3</h3>
                    <p>Deskripsi proyek ketiga Anda</p>
                </div>
            </div>
        </div>
    </section>

    <section id="contact" class="contact">
        <div class="container">
            <h2>Hubungi Saya</h2>
            <form class="contact-form">
                <input type="text" placeholder="Nama Anda" required>
                <input type="email" placeholder="Email Anda" required>
                <textarea placeholder="Pesan Anda" required></textarea>
                <button type="submit" class="btn btn-primary">Kirim Pesan</button>
            </form>
        </div>
    </section>

    <script src="script.js"></script>
</body>
</html>`
      },
      {
        id: '2',
        name: 'style.css',
        type: 'css',
        content: `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    line-height: 1.6;
    color: #333;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.navbar {
    background: #2c3e50;
    color: white;
    padding: 1rem 0;
    position: fixed;
    width: 100%;
    top: 0;
    z-index: 1000;
}

.nav-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.nav-menu {
    display: flex;
    list-style: none;
    gap: 2rem;
}

.nav-menu a {
    color: white;
    text-decoration: none;
    transition: color 0.3s;
}

.nav-menu a:hover {
    color: #3498db;
}

.hero {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 120px 20px 80px;
    text-align: center;
}

.hero-content h1 {
    font-size: 3rem;
    margin-bottom: 1rem;
}

.hero-content p {
    font-size: 1.2rem;
    margin-bottom: 2rem;
}

.hero-buttons {
    display: flex;
    gap: 1rem;
    justify-content: center;
}

.btn {
    padding: 12px 24px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    transition: all 0.3s;
}

.btn-primary {
    background: #3498db;
    color: white;
}

.btn-secondary {
    background: transparent;
    color: white;
    border: 2px solid white;
}

.btn:hover {
    transform: translateY(-2px);
}

section {
    padding: 80px 0;
}

.about {
    background: #f8f9fa;
}

.projects {
    background: white;
}

.contact {
    background: #f8f9fa;
}

h2 {
    text-align: center;
    margin-bottom: 3rem;
    font-size: 2.5rem;
}

.project-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
}

.project-card {
    background: white;
    padding: 2rem;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    transition: transform 0.3s;
}

.project-card:hover {
    transform: translateY(-5px);
}

.contact-form {
    max-width: 600px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.contact-form input,
.contact-form textarea {
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 16px;
}

.contact-form textarea {
    min-height: 120px;
    resize: vertical;
}

@media (max-width: 768px) {
    .nav-menu {
        flex-direction: column;
        gap: 1rem;
    }
    
    .hero-content h1 {
        font-size: 2rem;
    }
    
    .hero-buttons {
        flex-direction: column;
        align-items: center;
    }
}`
      },
      {
        id: '3',
        name: 'script.js',
        type: 'js',
        content: `// Smooth scrolling untuk navigasi
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Form submission handler
document.querySelector('.contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Ambil data form
    const name = this.querySelector('input[type="text"]').value;
    const email = this.querySelector('input[type="email"]').value;
    const message = this.querySelector('textarea').value;
    
    // Tampilkan pesan sukses
    alert('Terima kasih ' + name + '! Pesan Anda telah terkirim.');
    
    // Reset form
    this.reset();
});

// Animasi scroll untuk project cards
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observasi semua project cards
document.querySelectorAll('.project-card').forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(50px)';
    card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(card);
});

// Navbar background on scroll
window.addEventListener('scroll', function() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.background = '#34495e';
    } else {
        navbar.style.background = '#2c3e50';
    }
});`
      }
    ]
  },
  {
    id: 'calculator',
    name: 'Kalkulator',
    description: 'Kalkulator sederhana dengan antarmuka modern',
    icon: <Calculator className="h-6 w-6" />,
    files: [
      {
        id: '1',
        name: 'index.html',
        type: 'html',
        content: `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalkulator</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="calculator">
        <div class="display">
            <div class="previous-operand"></div>
            <div class="current-operand">0</div>
        </div>
        <button class="span-two">AC</button>
        <button>DEL</button>
        <button>÷</button>
        <button>1</button>
        <button>2</button>
        <button>3</button>
        <button>×</button>
        <button>4</button>
        <button>5</button>
        <button>6</button>
        <button>+</button>
        <button>7</button>
        <button>8</button>
        <button>9</button>
        <button>-</button>
        <button>.</button>
        <button>0</button>
        <button class="span-two">=</button>
    </div>
    <script src="script.js"></script>
</body>
</html>`
      },
      {
        id: '2',
        name: 'style.css',
        type: 'css',
        content: `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.calculator {
    background: #2d2d2d;
    border-radius: 20px;
    padding: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    max-width: 400px;
    width: 100%;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-gap: 10px;
}

.display {
    background: #1a1a1a;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;
    text-align: right;
    color: white;
    font-size: 2rem;
    min-height: 80px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    grid-column: 1 / -1;
}

.previous-operand {
    color: #888;
    font-size: 1rem;
    margin-bottom: 10px;
}

.current-operand {
    color: white;
    font-size: 2.5rem;
    font-weight: bold;
}

.calculator button {
    background: #4d4d4d;
    border: none;
    border-radius: 10px;
    color: white;
    font-size: 1.2rem;
    padding: 20px;
    margin: 5px;
    cursor: pointer;
    transition: all 0.3s;
    flex: 1;
}

.calculator button:hover {
    background: #5d5d5d;
    transform: translateY(-2px);
}

.calculator button:active {
    transform: translateY(0);
}

.calculator .span-two {
    grid-column: span 2;
}

.calculator button:nth-child(17) {
    background: #667eea;
}

.calculator button:nth-child(17):hover {
    background: #5a6fd8;
}

.calculator button:nth-child(4),
.calculator button:nth-child(8),
.calculator button:nth-child(12),
.calculator button:nth-child(16) {
    background: #ff6b6b;
}

.calculator button:nth-child(4):hover,
.calculator button:nth-child(8):hover,
.calculator button:nth-child(12):hover,
.calculator button:nth-child(16):hover {
    background: #ff5252;
}

@media (max-width: 480px) {
    .calculator {
        margin: 20px;
        padding: 15px;
    }
    
    .calculator button {
        padding: 15px;
        font-size: 1rem;
    }
    
    .current-operand {
        font-size: 2rem;
    }
}`
      },
      {
        id: '3',
        name: 'script.js',
        type: 'js',
        content: `class Calculator {
    constructor(previousOperandTextElement, currentOperandTextElement) {
        this.previousOperandTextElement = previousOperandTextElement;
        this.currentOperandTextElement = currentOperandTextElement;
        this.clear();
    }

    clear() {
        this.currentOperand = '';
        this.previousOperand = '';
        this.operation = undefined;
    }

    delete() {
        this.currentOperand = this.currentOperand.toString().slice(0, -1);
    }

    appendNumber(number) {
        if (number === '.' && this.currentOperand.includes('.')) return;
        this.currentOperand = this.currentOperand.toString() + number.toString();
    }

    chooseOperation(operation) {
        if (this.currentOperand === '') return;
        if (this.previousOperand !== '') {
            this.compute();
        }
        this.operation = operation;
        this.previousOperand = this.currentOperand;
        this.currentOperand = '';
    }

    compute() {
        let computation;
        const prev = parseFloat(this.previousOperand);
        const current = parseFloat(this.currentOperand);
        if (isNaN(prev) || isNaN(current)) return;
        switch (this.operation) {
            case '+':
                computation = prev + current;
                break;
            case '-':
                computation = prev - current;
                break;
            case '×':
                computation = prev * current;
                break;
            case '÷':
                computation = prev / current;
                break;
            default:
                return;
        }
        this.currentOperand = computation;
        this.operation = undefined;
        this.previousOperand = '';
    }

    getDisplayNumber(number) {
        const stringNumber = number.toString();
        const integerDigits = parseFloat(stringNumber.split('.')[0]);
        const decimalDigits = stringNumber.split('.')[1];
        let integerDisplay;
        if (isNaN(integerDigits)) {
            integerDisplay = '';
        } else {
            integerDisplay = integerDigits.toLocaleString('en', { maximumFractionDigits: 0 });
        }
        if (decimalDigits != null) {
            return \`\${integerDisplay}.\${decimalDigits}\`;
        } else {
            return integerDisplay;
        }
    }

    updateDisplay() {
        this.currentOperandTextElement.innerText = 
            this.getDisplayNumber(this.currentOperand);
        if (this.operation != null) {
            this.previousOperandTextElement.innerText = 
                \`\${this.getDisplayNumber(this.previousOperand)} \${this.operation}\`;
        } else {
            this.previousOperandTextElement.innerText = '';
        }
    }
}

const numberButtons = document.querySelectorAll('.calculator button');
const previousOperandTextElement = document.querySelector('.previous-operand');
const currentOperandTextElement = document.querySelector('.current-operand');

const calculator = new Calculator(previousOperandTextElement, currentOperandTextElement);

numberButtons.forEach(button => {
    button.addEventListener('click', () => {
        const text = button.innerText;
        
        if (text === 'AC') {
            calculator.clear();
            calculator.updateDisplay();
        } else if (text === 'DEL') {
            calculator.delete();
            calculator.updateDisplay();
        } else if (text === '=') {
            calculator.compute();
            calculator.updateDisplay();
        } else if (['+', '-', '×', '÷'].includes(text)) {
            calculator.chooseOperation(text);
            calculator.updateDisplay();
        } else {
            calculator.appendNumber(text);
            calculator.updateDisplay();
        }
    });
});

// Keyboard support
document.addEventListener('keydown', (event) => {
    const key = event.key;
    
    if (key >= '0' && key <= '9' || key === '.') {
        calculator.appendNumber(key);
        calculator.updateDisplay();
    } else if (key === '+' || key === '-' || key === '*' || key === '/') {
        const operation = key === '*' ? '×' : key === '/' ? '÷' : key;
        calculator.chooseOperation(operation);
        calculator.updateDisplay();
    } else if (key === 'Enter' || key === '=') {
        calculator.compute();
        calculator.updateDisplay();
    } else if (key === 'Escape') {
        calculator.clear();
        calculator.updateDisplay();
    } else if (key === 'Backspace') {
        calculator.delete();
        calculator.updateDisplay();
    }
});`
      }
    ]
  },
  {
    id: 'todo',
    name: 'Aplikasi To-Do',
    description: 'Aplikasi manajemen tugas sederhana',
    icon: <CheckSquare className="h-6 w-6" />,
    files: [
      {
        id: '1',
        name: 'index.html',
        type: 'html',
        content: `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="todo-app">
            <h1>To-Do List <i class="fas fa-clipboard-list"></i></h1>
            <div class="row">
                <input type="text" id="input-box" placeholder="Tambahkan tugas Anda...">
                <button id="add-btn">Tambah</button>
            </div>
            <ul id="list-container">
                <!-- Tugas akan ditambahkan di sini -->
            </ul>
            <div class="stats">
                <span id="total-tasks">0 tugas</span>
                <span id="completed-tasks">0 selesai</span>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>`
      },
      {
        id: '2',
        name: 'style.css',
        type: 'css',
        content: `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Arial', sans-serif;
}

body {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    padding: 20px;
}

.container {
    max-width: 600px;
    margin: 0 auto;
}

.todo-app {
    background: white;
    padding: 30px;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}

.todo-app h1 {
    color: #333;
    margin-bottom: 30px;
    text-align: center;
    font-size: 2rem;
}

.todo-app h1 i {
    color: #667eea;
    margin-left: 10px;
}

.row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background: #f8f9fa;
    border-radius: 30px;
    padding-left: 20px;
    margin-bottom: 25px;
}

input {
    flex: 1;
    border: none;
    outline: none;
    background: transparent;
    padding: 10px;
    font-size: 16px;
}

button {
    border: none;
    outline: none;
    padding: 12px 25px;
    background: #667eea;
    color: white;
    font-size: 16px;
    cursor: pointer;
    border-radius: 30px;
    transition: background 0.3s;
}

button:hover {
    background: #5a6fd8;
}

ul {
    list-style: none;
    margin-bottom: 20px;
}

ul li {
    font-size: 16px;
    padding: 12px 8px 12px 50px;
    user-select: none;
    cursor: pointer;
    position: relative;
    background: #f8f9fa;
    margin-bottom: 10px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

ul li::before {
    content: '';
    position: absolute;
    height: 20px;
    width: 20px;
    border-radius: 50%;
    background: #ddd;
    top: 12px;
    left: 15px;
    border: 2px solid #999;
}

ul li.checked {
    color: #555;
    text-decoration: line-through;
    background: #e8f5e8;
}

ul li.checked::before {
    background: #4caf50;
    border-color: #4caf50;
}

ul li.checked::after {
    content: '✓';
    position: absolute;
    left: 20px;
    top: 8px;
    color: white;
    font-size: 14px;
    font-weight: bold;
}

ul li span {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    font-size: 18px;
    color: #ff6b6b;
    line-height: 20px;
    text-align: center;
    border-radius: 50%;
    cursor: pointer;
    transition: background 0.3s;
}

ul li span:hover {
    background: #ffebee;
}

.stats {
    display: flex;
    justify-content: space-between;
    padding: 15px 0;
    border-top: 1px solid #eee;
    color: #666;
    font-size: 14px;
}

@media (max-width: 480px) {
    .container {
        padding: 10px;
    }
    
    .todo-app {
        padding: 20px;
    }
    
    .todo-app h1 {
        font-size: 1.5rem;
    }
    
    .row {
        flex-direction: column;
        gap: 10px;
        padding: 15px;
    }
    
    button {
        width: 100%;
    }
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

ul li {
    animation: slideIn 0.3s ease-out;
}`
      },
      {
        id: '3',
        name: 'script.js',
        type: 'js',
        content: `const inputBox = document.getElementById("input-box");
const listContainer = document.getElementById("list-container");
const addBtn = document.getElementById("add-btn");
const totalTasksSpan = document.getElementById("total-tasks");
const completedTasksSpan = document.getElementById("completed-tasks");

// Load tasks from localStorage
function loadTasks() {
    const savedTasks = localStorage.getItem("tasks");
    if (savedTasks) {
        listContainer.innerHTML = savedTasks;
        updateStats();
        attachEventListeners();
    }
}

// Save tasks to localStorage
function saveTasks() {
    localStorage.setItem("tasks", listContainer.innerHTML);
}

// Update statistics
function updateStats() {
    const totalTasks = listContainer.children.length;
    const completedTasks = listContainer.querySelectorAll(".checked").length;
    
    totalTasksSpan.textContent = \`\${totalTasks} tugas\`;
    completedTasksSpan.textContent = \`\${completedTasks} selesai\`;
}

// Add task
function addTask() {
    if (inputBox.value === '') {
        alert("Anda harus menulis sesuatu!");
    } else {
        let li = document.createElement("li");
        li.innerHTML = inputBox.value;
        
        // Add delete button
        let span = document.createElement("span");
        span.innerHTML = "\\u00D7";
        li.appendChild(span);
        
        listContainer.appendChild(li);
        inputBox.value = "";
        
        saveTasks();
        updateStats();
        attachEventListeners();
    }
}

// Attach event listeners to list items
function attachEventListeners() {
    const listItems = listContainer.querySelectorAll("li");
    
    listItems.forEach(item => {
        // Toggle checked state
        item.addEventListener("click", function(e) {
            if (e.target.tagName !== "SPAN") {
                this.classList.toggle("checked");
                saveTasks();
                updateStats();
            }
        });
        
        // Delete task
        const deleteBtn = item.querySelector("span");
        if (deleteBtn) {
            deleteBtn.addEventListener("click", function(e) {
                e.stopPropagation();
                this.parentElement.remove();
                saveTasks();
                updateStats();
            });
        }
    });
}

// Event listeners
addBtn.addEventListener("click", addTask);

inputBox.addEventListener("keypress", function(e) {
    if (e.key === "Enter") {
        addTask();
    }
});

// Keyboard shortcuts
document.addEventListener("keydown", function(e) {
    // Ctrl/Cmd + K to focus input
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        inputBox.focus();
    }
    
    // Escape to clear input
    if (e.key === 'Escape') {
        inputBox.value = "";
        inputBox.blur();
    }
});

// Add some sample tasks for first-time users
function addSampleTasks() {
    if (listContainer.children.length === 0) {
        const sampleTasks = [
            "Belajar JavaScript",
            "Buat proyek web",
            "Olahraga pagi"
        ];
        
        sampleTasks.forEach(taskText => {
            let li = document.createElement("li");
            li.innerHTML = taskText;
            
            let span = document.createElement("span");
            span.innerHTML = "\\u00D7";
            li.appendChild(span);
            
            listContainer.appendChild(li);
        });
        
        saveTasks();
        updateStats();
        attachEventListeners();
    }
}

// Initialize the app
document.addEventListener("DOMContentLoaded", function() {
    loadTasks();
    
    // Add sample tasks if no tasks exist
    if (listContainer.children.length === 0) {
        addSampleTasks();
    }
    
    // Focus input on load
    inputBox.focus();
});

// Export functions for potential future use
window.todoApp = {
    addTask,
    clearCompleted: function() {
        const completedTasks = listContainer.querySelectorAll(".checked");
        completedTasks.forEach(task => task.remove());
        saveTasks();
        updateStats();
    },
    clearAll: function() {
        if (confirm("Apakah Anda yakin ingin menghapus semua tugas?")) {
            listContainer.innerHTML = "";
            saveTasks();
            updateStats();
        }
    }
};`
      }
    ]
  }
];

const getLanguageFromType = (type: string) => {
  switch (type) {
    case 'html': return 'html';
    case 'css': return 'css';
    case 'js': return 'javascript';
    case 'json': return 'json';
    default: return 'plaintext';
  }
};

export default function Home() {
  const [files, setFiles] = useState<FileData[]>(templates[0].files);
  const [activeFileId, setActiveFileId] = useState<string>('1');
  const [previewMode, setPreviewMode] = useState<boolean>(false);
  const [showTemplates, setShowTemplates] = useState<boolean>(false);

  const activeFile = files.find(f => f.id === activeFileId) || files[0];

  const updateFileContent = (content: string) => {
    setFiles(files.map(f => 
      f.id === activeFileId ? { ...f, content } : f
    ));
  };

  const addNewFile = () => {
    const newFile: FileData = {
      id: Date.now().toString(),
      name: `file_${files.length + 1}.html`,
      type: 'html',
      content: `<!-- File baru -->\n<!DOCTYPE html>\n<html>\n<head>\n    <title>File Baru</title>\n</head>\n<body>\n    <h1>File Baru</h1>\n</body>\n</html>`
    };
    setFiles([...files, newFile]);
    setActiveFileId(newFile.id);
  };

  const deleteFile = (fileId: string) => {
    if (files.length <= 1) return;
    const newFiles = files.filter(f => f.id !== fileId);
    setFiles(newFiles);
    if (activeFileId === fileId) {
      setActiveFileId(newFiles[0].id);
    }
  };

  const loadTemplate = (template: Template) => {
    setFiles(template.files.map(f => ({ ...f, id: Date.now().toString() + Math.random().toString() })));
    setActiveFileId(template.files[0].id);
    setShowTemplates(false);
  };

  const generatePreview = () => {
    const htmlFile = files.find(f => f.type === 'html');
    const cssFile = files.find(f => f.type === 'css');
    const jsFile = files.find(f => f.type === 'js');
    
    let htmlContent = htmlFile?.content || '';
    
    if (cssFile) {
      htmlContent = htmlContent.replace(
        '</head>',
        `<style>${cssFile.content}</style></head>`
      );
    }
    
    if (jsFile) {
      htmlContent = htmlContent.replace(
        '</body>',
        `<script>${jsFile.content}</script></body>`
      );
    }
    
    return htmlContent;
  };

  const downloadFiles = () => {
    files.forEach(file => {
      const blob = new Blob([file.content], { 
        type: file.type === 'html' ? 'text/html' : 
             file.type === 'css' ? 'text/css' : 
             file.type === 'js' ? 'text/javascript' : 'text/plain' 
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      a.click();
      URL.revokeObjectURL(url);
    });
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'html': return '📄';
      case 'css': return '🎨';
      case 'js': return '⚡';
      case 'json': return '📋';
      default: return '📄';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <Code className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Web App Builder</h1>
                <p className="text-sm text-gray-500">Buat aplikasi web dengan mudah</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Dialog open={showTemplates} onOpenChange={setShowTemplates}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <LayoutTemplate className="h-4 w-4" />
                    Template
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl">
                  <DialogHeader>
                    <DialogTitle>Pilih Template</DialogTitle>
                    <DialogDescription>
                      Pilih template untuk memulai proyek Anda dengan cepat
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {templates.map((template) => (
                      <Card 
                        key={template.id} 
                        className="cursor-pointer hover:shadow-lg transition-shadow"
                        onClick={() => loadTemplate(template)}
                      >
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            {template.icon}
                            {template.name}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-600">{template.description}</p>
                          <div className="mt-2">
                            <Badge variant="secondary">
                              {template.files.length} file
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button 
                variant="outline" 
                onClick={() => setPreviewMode(!previewMode)}
                className="flex items-center gap-2"
              >
                {previewMode ? <Eye className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                {previewMode ? 'Edit Mode' : 'Preview'}
              </Button>
              <Button 
                onClick={downloadFiles}
                className="flex items-center gap-2"
              >
                <Download className="h-4 w-4" />
                Download All Files
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-4">
        {previewMode ? (
          /* Preview Mode */
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                Preview Aplikasi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <iframe
                  srcDoc={generatePreview()}
                  className="w-full h-96 md:h-[600px]"
                  title="Preview"
                  sandbox="allow-scripts"
                />
              </div>
            </CardContent>
          </Card>
        ) : (
          /* Edit Mode */
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
            {/* File Manager Sidebar */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <FolderOpen className="h-5 w-5" />
                    File Manager
                  </span>
                  <Button size="sm" variant="ghost" onClick={addNewFile}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {files.map((file) => (
                  <div
                    key={file.id}
                    className={`p-3 rounded-lg cursor-pointer transition-colors ${
                      activeFileId === file.id 
                        ? 'bg-blue-100 border-blue-300 border' 
                        : 'hover:bg-gray-100'
                    }`}
                    onClick={() => setActiveFileId(file.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getFileIcon(file.type)}</span>
                        <div>
                          <div className="font-medium text-sm">{file.name}</div>
                          <Badge variant="secondary" className="text-xs">
                            {file.type.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                      {files.length > 1 && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteFile(file.id);
                          }}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Code Editor */}
            <Card className="lg:col-span-3">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Editor: {activeFile?.name}
                  </span>
                  <Badge variant="outline">{activeFile?.type.toUpperCase()}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="fileName">File Name</Label>
                      <Input
                        id="fileName"
                        value={activeFile?.name || ''}
                        onChange={(e) => {
                          setFiles(files.map(f => 
                            f.id === activeFileId 
                              ? { ...f, name: e.target.value }
                              : f
                          ));
                        }}
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="fileType">File Type</Label>
                      <Select
                        value={activeFile?.type || 'html'}
                        onValueChange={(value: any) => {
                          setFiles(files.map(f => 
                            f.id === activeFileId 
                              ? { ...f, type: value as FileData['type'] }
                              : f
                          ));
                        }}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="html">HTML</SelectItem>
                          <SelectItem value="css">CSS</SelectItem>
                          <SelectItem value="js">JavaScript</SelectItem>
                          <SelectItem value="json">JSON</SelectItem>
                          <SelectItem value="txt">Text</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="codeEditor">Code Editor</Label>
                    <div className="mt-1">
                      <SimpleCodeEditor
                        height="400px"
                        language={getLanguageFromType(activeFile?.type || 'html')}
                        value={activeFile?.content || ''}
                        onChange={updateFileContent}
                        className="w-full"
                      />
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-4 border-t">
                    <div className="text-sm text-gray-500">
                      {activeFile?.content.split('\n').length} lines • {activeFile?.content.length} characters
                    </div>
                    <Button className="flex items-center gap-2">
                      <Save className="h-4 w-4" />
                      Save Changes
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}