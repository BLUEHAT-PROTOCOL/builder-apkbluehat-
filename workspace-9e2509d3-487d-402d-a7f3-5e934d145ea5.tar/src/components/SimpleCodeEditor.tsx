'use client';

import { useState, useEffect, useRef } from 'react';

interface SimpleCodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language: 'html' | 'css' | 'javascript' | 'json' | 'plaintext';
  height?: string;
  className?: string;
}

const getSyntaxHighlighting = (code: string, language: string): string => {
  // Simple syntax highlighting regex patterns
  const patterns = {
    html: {
      tags: /(<\\/?\\w+|>)/g,
      attributes: /(\\w+)="[^"]*"/g,
      comments: /(<!--[^>]*-->)/g,
    },
    css: {
      selectors: /([^{]+)\\{/g,
      properties: /([a-zA-Z-]+):/g,
      values: /:\\s*([^;]+);/g,
      comments: /(\\/\\*[^*]*\\*\\/)/g,
    },
    javascript: {
      keywords: /\\b(function|return|var|let|const|if|else|for|while|do|switch|case|break|continue|try|catch|finally|class|extends|import|export|default|async|await)\\b/g,
      strings: /("[^"]*"|'[^']*'|`[^`]*`)/g,
      comments: /(\\/\\/.*|\\/\\*[^*]*\\*\\/)/g,
      functions: /\\b(\\w+)\\s*\\(/g,
    },
    json: {
      keys: /"([^"]+)":/g,
      strings: /"[^"]*"/g,
      numbers: /\\b(\\d+(?:\\.\\d+)?)\\b/g,
      booleans: /\\b(true|false|null)\\b/g,
    }
  };

  let highlighted = code
    .replace(/&/g, '&')
    .replace(/</g, '<')
    .replace(/>/g, '>')
    .replace(/\"/g, '"')
    .replace(/'/g, ''');

  const langPatterns = patterns[language as keyof typeof patterns] || patterns.javascript;
  
  // Apply highlighting patterns
  Object.entries(langPatterns).forEach(([type, regex]) => {
    highlighted = highlighted.replace(regex, (match) => {
      const colors = {
        tags: 'text-blue-600',
        attributes: 'text-green-600',
        comments: 'text-gray-500 italic',
        selectors: 'text-purple-600',
        properties: 'text-cyan-600',
        values: 'text-orange-600',
        keywords: 'text-blue-600 font-semibold',
        strings: 'text-green-600',
        functions: 'text-yellow-600',
        keys: 'text-purple-600',
        numbers: 'text-orange-600',
        booleans: 'text-red-600',
      };
      return `<span class="${colors[type as keyof typeof colors] || 'text-inherit'}">${match}</span>`;
    });
  });

  return highlighted;
};

export default function SimpleCodeEditor({ 
  value, 
  onChange, 
  language, 
  height = '400px',
  className = '' 
}: SimpleCodeEditorProps) {
  const [lineNumbers, setLineNumbers] = useState<string[]>(['1']);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);

  const updateLineNumbers = (text: string) => {
    const lines = text.split('\n');
    const numbers = lines.map((_, index) => (index + 1).toString());
    setLineNumbers(numbers);
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    onChange(newValue);
    updateLineNumbers(newValue);
  };

  const handleScroll = () => {
    if (textareaRef.current && preRef.current) {
      preRef.current.scrollTop = textareaRef.current.scrollTop;
      preRef.current.scrollLeft = textareaRef.current.scrollLeft;
    }
  };

  useEffect(() => {
    updateLineNumbers(value);
  }, [value]);

  const highlightedCode = getSyntaxHighlighting(value, language);

  return (
    <div className={`relative font-mono text-sm border rounded-lg overflow-hidden bg-gray-900 ${className}`}>
      <div className="flex">
        {/* Line numbers */}
        <div className="bg-gray-800 text-gray-400 px-3 py-2 select-none text-right border-r border-gray-700">
          {lineNumbers.map((num, index) => (
            <div key={index} className="leading-6">
              {num}
            </div>
          ))}
        </div>
        
        {/* Code area */}
        <div className="flex-1 relative">
          <textarea
            ref={textareaRef}
            value={value}
            onChange={handleChange}
            onScroll={handleScroll}
            className="absolute inset-0 w-full h-full bg-transparent text-transparent caret-white resize-none outline-none p-2 font-mono text-sm leading-6"
            style={{ height }}
            spellCheck={false}
            placeholder="Tulis kode Anda di sini..."
          />
          <pre
            ref={preRef}
            className="absolute inset-0 w-full h-full overflow-auto p-2 font-mono text-sm leading-6 pointer-events-none"
            style={{ height }}
          >
            <code
              className="block"
              dangerouslySetInnerHTML={{ __html: highlightedCode || '<span class="text-gray-500">Tulis kode Anda di sini...</span>' }}
            />
          </pre>
        </div>
      </div>
      
      {/* Language indicator */}
      <div className="absolute top-2 right-2 bg-gray-800 text-gray-300 px-2 py-1 rounded text-xs">
        {language.toUpperCase()}
      </div>
    </div>
  );
}