# 🚀 Panduan Deployment Web App Builder

## 📋 Prasyarat

- Akun Cloudflare (gratis)
- Akun GitHub (untuk auto-deployment)
- Node.js terinstall di lokal

## 🔧 Metode 1: Cloudflare Pages (Rekomendasi)

### 1. Build Aplikasi

```bash
# Install dependencies
npm install

# Build aplikasi untuk production
npm run build
```

### 2. Push ke GitHub

```bash
# Inisialisasi git jika belum
git init

# Tambahkan remote repository
git remote add origin https://github.com/username/nama-repo.git

# Add semua file
git add .

# Commit changes
git commit -m "Initial commit - Web App Builder"

# Push ke GitHub
git push -u origin main
```

### 3. Setup Cloudflare Pages

1. **Login ke Cloudflare Dashboard**
   - Buka [dash.cloudflare.com](https://dash.cloudflare.com)
   - Login dengan akun Anda

2. **Buat Project Baru**
   - Klik "Pages" di sidebar kiri
   - Klik "Create a project"
   - Pilih "Connect to Git"

3. **Pilih Repository**
   - Cari repository GitHub Anda
   - Klik "Connect"

4. **Konfigurasi Build**
   ```
   Build command: npm run build
   Build output directory: out
   Root directory: / (kosongkan)
   ```

5. **Environment Variables** (jika diperlukan)
   - Tambahkan variabel jika ada
   - Klik "Save and Deploy"

### 4. Deployment Otomatis

Setiap kali Anda push ke branch main, Cloudflare akan otomatis:
- Build aplikasi
- Deploy ke production
- Memberikan URL seperti `https://nama-project.pages.dev`

## 🔧 Metode 2: Cloudflare Workers dengan Wrangler

### 1. Install Wrangler CLI

```bash
# Install Wrangler globally
npm install -g wrangler

# Login ke Cloudflare
wrangler login
```

### 2. Build Aplikasi

```bash
npm run build
```

### 3. Deploy dengan Wrangler

```bash
# Deploy ke Cloudflare Workers
npm run deploy:cf
```

Atau manual:

```bash
wrangler deploy
```

## 🐛 Troubleshooting

### Issue 1: Build Gagal

**Error:** `Module not found: Can't resolve 'monaco-editor'`

**Solution:** Monaco Editor sudah direplace dengan SimpleCodeEditor yang lebih ringan

### Issue 2: Static Generation Error

**Error:** `Error occurred prerendering page "/"`

**Solution:** Pastikan semua komponen client-side memiliki `'use client'`

### Issue 3: Routing Error di Production

**Error:** 404 saat refresh halaman

**Solution:** File `_redirects` dan `_headers` sudah disiapkan untuk handle SPA routing

### Issue 4: Large Bundle Size

**Solution:** Aplikasi sudah dioptimasi dengan tree shaking dan code splitting

## 📊 Optimasi untuk Production

### 1. Environment Variables

Buat file `.env.production`:

```env
NEXT_PUBLIC_APP_URL=https://your-domain.pages.dev
NEXT_PUBLIC_APP_NAME="Web App Builder"
```

### 2. Analytics (Opsional)

Tambahkan Cloudflare Web Analytics:

```html
<script
  defer
  src='https://static.cloudflareinsights.com/beacon.min.js'
  data-cf-beacon='{"token": "YOUR_TOKEN"}'
></script>
```

### 3. Custom Domain

1. **Di Cloudflare Pages:**
   - Pilih project Anda
   - Klik "Custom domains"
   - Tambahkan domain Anda

2. **Setup DNS:**
   - Tambahkan CNAME record di DNS provider Anda
   - Point ke `pages.dev`

## 📱 Testing di Production

Setelah deployment, test fitur-fitur berikut:

1. **Basic Functionality:**
   - Buat project baru
   - Edit file HTML/CSS/JS
   - Preview aplikasi
   - Download files

2. **Mobile Testing:**
   - Buka di mobile browser
   - Test responsive layout
   - Test touch interactions

3. **Browser Compatibility:**
   - Chrome, Firefox, Safari, Edge
   - Test syntax highlighting
   - Test file operations

## 🎯 Fitur yang Sudah Di-optimasi

✅ **Static Export** - Dapat di-deploy sebagai static site  
✅ **No Server Dependencies** - Pure client-side application  
✅ **SEO Friendly** - Meta tags dan structured data  
✅ **Responsive Design** - Mobile-first approach  
✅ **Performance Optimized** - Lazy loading dan code splitting  
✅ **PWA Ready** - Service worker dan manifest support  

---

🎉 **Selamat! Web App Builder Anda siap di-deploy ke Cloudflare!**