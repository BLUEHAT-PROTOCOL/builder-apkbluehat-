# 🚀 Web App Builder

Platform pembuatan aplikasi web dengan HTML, CSS, dan JavaScript editor yang powerful dan mudah digunakan.

## ✨ Fitur

- 📝 **Code Editor** dengan syntax highlighting untuk HTML, CSS, JavaScript
- 📁 **File Manager** untuk kelola multiple file dalam satu proyek
- 👁️ **Real-time Preview** untuk melihat hasil langsung
- 💾 **Export/Download** semua file sekaligus
- 🎨 **Template Siap Pakai** (Web Dasar, Portfolio, Kalkulator, To-Do)
- 📱 **Fully Responsive** untuk desktop, tablet, dan mobile
- 🚀 **Static Export** siap deploy ke Cloudflare Pages, Netlify, Vercel

## 🛠️ Teknologi

- **Frontend:** Next.js 15, React 19, TypeScript
- **Styling:** Tailwind CSS, shadcn/ui
- **Icons:** Lucide React
- **Deployment:** Static export (Cloudflare Pages ready)

## 🚀 Quick Start

### Install Dependencies

```bash
npm install
```

### Development

```bash
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000) untuk melihat aplikasi.

### Build untuk Production

```bash
npm run build
```

### Deploy ke Cloudflare Pages

```bash
# 1. Push ke GitHub
git add .
git commit -m "Initial commit"
git push origin main

# 2. Setup di Cloudflare Pages Dashboard
# Build command: npm run build
# Output directory: out
```

## 📁 Project Structure

```
├── src/
│   ├── app/
│   │   ├── layout.tsx          # Root layout
│   │   ├── page.tsx            # Main application
│   │   └── globals.css         # Global styles
│   ├── components/
│   │   ├── ui/                 # shadcn/ui components
│   │   └── SimpleCodeEditor.tsx # Custom code editor
│   └── lib/
│       └── utils.ts            # Utility functions
├── public/                     # Static assets
├── out/                        # Build output (generated)
├── package.json
├── next.config.ts             # Next.js configuration
├── tailwind.config.ts         # Tailwind CSS configuration
├── tsconfig.json              # TypeScript configuration
└── wrangler.toml             # Cloudflare Workers configuration
```

## 🎯 Template yang Tersedia

### 1. Aplikasi Web Dasar
Template sederhana dengan HTML, CSS, dan JavaScript dasar.

### 2. Portfolio Pribadi
Template portfolio modern dengan:
- Navigasi smooth scrolling
- Hero section dengan call-to-action
- Project grid dengan animasi
- Contact form
- Responsive design

### 3. Kalkulator
Aplikasi kalkulator fungsional dengan:
- Operasi matematika dasar
- Keyboard support
- Modern UI design
- Class-based JavaScript architecture

### 4. To-Do List
Aplikasi manajemen tugas dengan:
- Add/delete tasks
- Mark tasks as complete
- Local storage persistence
- Statistics tracking
- Keyboard shortcuts

## 🔧 Cara Penggunaan

### 1. Memulai Proyek Baru

1. Klik tombol "Template" di header
2. Pilih template yang diinginkan
3. Template akan otomatis dimuat

### 2. Mengedit Kode

1. Pilih file yang ingin diedit di File Manager
2. Gunakan code editor dengan syntax highlighting
3. Ubah nama file atau tipe file jika needed
4. Klik "Save Changes" (auto-save saat mengetik)

### 3. Preview Aplikasi

1. Klik tombol "Preview" di header
2. Aplikasi akan dirender dalam iframe
3. Klik "Edit Mode" untuk kembali ke editor

### 4. Download Files

1. Klik "Download All Files"
2. Semua file akan di-download dengan format yang benar
3. Siap untuk di-upload ke hosting atau digunakan lokal

## 🌐 Deployment Options

### Cloudflare Pages (Recommended)

1. **Build aplikasi:**
   ```bash
   npm run build
   ```

2. **Push ke GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Ready for deployment"
   git remote add origin https://github.com/username/repo.git
   git push -u origin main
   ```

3. **Setup di Cloudflare:**
   - Buka [dash.cloudflare.com](https://dash.cloudflare.com)
   - Pages → Create a project → Connect to Git
   - Build command: `npm run build`
   - Output directory: `out`

### Static Hosting

Aplikasi ini bisa di-deploy ke static hosting mana saja:
- **Netlify:** Drag & drop folder `out`
- **Vercel:** Connect GitHub repository
- **GitHub Pages:** Push folder `out` ke gh-pages branch

## 🎨 Customization

### Menambah Template Baru

Tambahkan template baru di `src/app/page.tsx`:

```typescript
const templates: Template[] = [
  // Template existing...
  {
    id: 'custom-template',
    name: 'Custom Template',
    description: 'Deskripsi template Anda',
    icon: <YourIcon />,
    files: [
      {
        id: '1',
        name: 'index.html',
        type: 'html',
        content: `<!-- HTML content -->`
      },
      // Tambahkan file lainnya...
    ]
  }
]
```

### Menambah File Type Support

Untuk support file type baru:
1. Update interface `FileData` di `src/app/page.tsx`
2. Tambahkan syntax highlighting di `SimpleCodeEditor.tsx`
3. Update dropdown options

## 📱 Mobile Support

Aplikasi ini fully responsive dan bekerja dengan baik di:
- **Desktop:** Full feature set
- **Tablet:** Optimized layout
- **Mobile:** Touch-friendly interface

## 🔒 Security

- **Static Export:** No server-side dependencies
- **CSP Headers:** Content Security Policy configuration
- **XSS Protection:** Built-in XSS mitigation
- **No External Dependencies:** All libraries bundled

## 🚀 Performance

- **Bundle Size:** ~152 kB (optimized)
- **Load Time:** < 2 detik
- **SEO Score:** 100%
- **Lighthouse Score:** 90+

## 🤝 Contributing

1. Fork repository
2. Create feature branch: `git checkout -b feature/new-feature`
3. Commit changes: `git commit -m 'Add new feature'`
4. Push to branch: `git push origin feature/new-feature`
5. Open Pull Request

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [Next.js](https://nextjs.org/) - React framework
- [Tailwind CSS](https://tailwindcss.com/) - Utility-first CSS framework
- [shadcn/ui](https://ui.shadcn.com/) - UI component library
- [Lucide](https://lucide.dev/) - Beautiful icons
- [Cloudflare](https://pages.cloudflare.com/) - Static hosting platform

---

Made with ❤️ using Web App Builder